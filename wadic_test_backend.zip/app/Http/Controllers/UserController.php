<?php

namespace App\Http\Controllers;
use Illuminate\Http\Request;
use App\Models\User;
class UserController extends Controller
{
    //

    public function SaveUser(Request $request){
            //
            $validator = \Validator::make($request->all(), 
            [
            'email' => 'required|email|unique:users',
            'first_name' => 'required',
            'last_name' => 'required',
            'gender' => 'required',
            'city' => 'required',
            'postcode' => 'required',
            'country' => 'required',
            'state' => 'required',
            ]);

            if ($validator->fails()) {
            return response()->json($validator->errors(), 422);
            }else {
            # code...
            User::create($request->all());
            //
            return response()->json('User Saved Successfully',200);
            }

            

    }

}
