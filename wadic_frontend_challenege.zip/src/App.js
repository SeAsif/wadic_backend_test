import React from "react";
import "./App.css";
import "bootstrap/dist/css/bootstrap.min.css";

import User from "./components/user.component";

function App() {
  return (
    <div className="container" style={{ width: "50%",padding:"15px" }}>
      <div style={{ margin: "20px" }}>
      </div>

      <User />
    </div>
  );
}

export default App;
