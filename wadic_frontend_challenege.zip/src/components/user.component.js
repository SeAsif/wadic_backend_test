import React, { Component } from "react";
import UserService from "../services/user.service";

export default class User extends Component {
  constructor(props) {
   
    super(props);
    this.state = {
      first_name: '',
      last_name: '',
      postcode: '',
      city: '',
      gender: '',
      country: '',
      email: '',
      state: '',
      savebtn: undefined,
      alert: '',
      message: ''
    };
  }

  /** Get Random user from Api */
  FindRandomUser = async () => {
    try {
      await UserService.FindRandomUser()
        .then(res => {
          // User Data
          const response = res.data.results[0];
          //
          // Fill all fileds
          this.setState({
            alert: 'alert alert-success',
            message: 'User Retrieved Successfully',
            first_name: response.name.first,
            last_name: response.name.last,
            gender: response.gender,
            email: response.email,
            postcode: response.location.postcode,
            city: response.location.city,
            country: response.location.country,
            state: response.location.state,
            savebtn: true
          });
          //
          // Hide Alert
          setTimeout(() => {
            this.setState({
              alert: '',
              message: ''
            })
          }, 5000);
          //
        });
    } catch (err) {
      this.setState({
        alert: 'alert alert-danger',
        message: err.message
      });
      
    }
  }

  /** Save user into Database */
  SaveUser = async () => {
   
    try {
      const data = {
        first_name: this.state.first_name,
        last_name: this.state.last_name,
        gender: this.state.gender,
        email: this.state.email,
        postcode: this.state.postcode,
        city: this.state.city,
        country: this.state.country,
        state: this.state.state,
      }
      await UserService.SaveUser(data).then(res => {
        if (res.status == 200) {
          console.log(res)
          this.setState({
            alert: 'alert alert-success',
            message: res.data,
            savebtn: undefined,
          })
          // Hide Alert
          setTimeout(() => {
            this.setState({
              alert: '',
              message: ''
            })
          }, 5000);
          //
        }
      })
    } catch (err) {
      this.setState({
        alert: 'alert alert-danger',
        message: err.message
      });
    }
   
  }


  render() {
    const {
      savebtn,
    } = this.state;

    return (
      <div>
        <div className={this.state.alert} role="alert">
          {this.state.message}
        </div>

        <div className="card">

          <div className="card-header" style={{ marginBottom: "10px", textAlign: "center", fontWeight: 'bold', }}>
            Wadic Frontend Challenge
          </div>

          <div className="card-body">
            <div className="form-row" style={{ marginBottom: "10px" }}>
              <label className="col-md-2">Firstname:</label>
              <div className="col-md-10">
                <input type="text" value={this.state.first_name} className="form-control"></input>
              </div>
            </div>


            <div className="form-row" style={{ marginBottom: "10px" }}>
              <label className="col-md-2">Lastname:</label>
              <div className="col-md-10">
                <input type="text" value={this.state.last_name} className="form-control"></input>
              </div>
            </div>


            <div className="form-row" style={{ marginBottom: "10px" }}>
              <label className="col-md-2">Email:</label>
              <div className="col-md-10">
                <input type="text" value={this.state.email} className="form-control"></input>
              </div>
            </div>

            <div className="form-row" style={{ marginBottom: "10px" }}>
              <label className="col-md-2">City:</label>
              <div className="col-md-10">
                <input type="text" value={this.state.city} className="form-control"></input>
              </div>
            </div>

            <div className="form-row" style={{ marginBottom: "10px" }}>
              <label className="col-md-2">Country:</label>
              <div className="col-md-10">
                <input type="text" value={this.state.country} className="form-control"></input>
              </div>
            </div>

            <div className="form-row" style={{ marginBottom: "10px" }}>
              <label className="col-md-2">Satate:</label>
              <div className="col-md-10">
                <input type="text" value={this.state.state} className="form-control"></input>
              </div>
            </div>

            <div className="form-row" style={{ marginBottom: "10px" }}>
              <label className="col-md-2">Postcode:</label>
              <div className="col-md-10">
                <input type="text" value={this.state.postcode} className="form-control"></input>
              </div>
            </div>


            <fieldset className="form-group">
              <div className="row">
                <legend className="col-form-label col-sm-2 pt-0">Gender</legend>
                <div className="col-sm-10">
                  <div className="form-check">
                    <input className="form-check-input" type="radio" value="male" checked={this.state.gender == "male" ? true : false}></input>
                    <label className="form-check-label" for="gridRadios1">
                      Male
                    </label>
                  </div>

                  <div className="form-check">
                    <input className="form-check-input" type="radio" value="female" checked={this.state.gender == "female" ? true : false}></input>
                    <label className="form-check-label" for="gridRadios2">
                      Female
                    </label>
                  </div>
                </div>
              </div>
            </fieldset>



            <div className="form-row" style={{ marginBottom: "10px" }}>
              <label className="col-md-2"></label>
              <button className="btn btn-primary col-md-4" onClick={this.FindRandomUser} style={{ margin: "10px" }}>
                Find Random User
              </button>
              <button className="btn btn-danger col-md-4" disabled={!savebtn} onClick={this.SaveUser} style={{ margin: "10px" }}>
                Accept and Save
              </button>
            </div>
          </div>

        </div>
      </div>
    );
  }
}
