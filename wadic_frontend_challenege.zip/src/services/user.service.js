import http from "../http_common";

class UserService {

  /** Get User */
  FindRandomUser() {
    return http.get('https://randomuser.me/api/');
  }

  /** Save User */
  SaveUser(data) {
    return http.post('http://localhost:8000/api/v1/saveuser', data);
  }

}

export default new UserService();
